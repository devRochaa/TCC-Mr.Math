export default [
  {
    src: "../img/video.mp4",
    title: "Editando fotos",
  },
  {
    src: "../img/video2.mp4",
    title: "3fff",
  },


];