<?php
if ($_SESSION["usuario"] == "guilherme@gmail.com") {
  $admin = true;
} else {
  $admin = false;
}
